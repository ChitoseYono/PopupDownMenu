package com.example.chitose.popupdemo.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.chitose.popupdemo.R;

/**
 * Created by Chitose on 2018/5/1.
 */

public class MenuPopup extends PopupWindow {

    public MenuPopup(View contentView, int width, int height, boolean focusable, final Context mContext, TextView tv_demo) {
        super(contentView, width, height, focusable);
        //设置PopupWindow的背景
        Drawable drawable = ContextCompat.getDrawable(mContext, R.drawable.bg_filter_down);
        this.setBackgroundDrawable(drawable);
        //设置焦点不在PopupWindow上，才能点击其他内容
        this.setFocusable(false);
        //点外围而dismiss的效果需要人为操作
        this.setOutsideTouchable(false);
        //创建后立即呈现
        if (!this.isShowing()) {
            this.showAsDropDown(tv_demo,0,5);
        }

    }

}
