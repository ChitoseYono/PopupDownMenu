package com.example.chitose.popupdemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.chitose.popupdemo.entity.PopItem;
import com.example.chitose.popupdemo.R;

import java.util.List;

/**
 * Created by Chitose on 2018/5/1.
 */

public class PopAdapter extends BaseAdapter {

    private Context mContext;
    private List<PopItem> mList;

    public PopAdapter(Context mContext, List<PopItem> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.popup_item, null);
            holder.tv_item = convertView.findViewById(R.id.tv_item);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tv_item.setText(mList.get(position).getContent());

        return convertView;
    }

    private class ViewHolder {
        TextView tv_item;
    }
}
