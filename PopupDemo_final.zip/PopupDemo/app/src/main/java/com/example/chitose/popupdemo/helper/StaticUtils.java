package com.example.chitose.popupdemo.helper;

/**
 * Created by Chitose on 2018/5/1.
 */

public class StaticUtils {
    private StaticUtils() {

    }
    //用于辨别菜单类型
    public static final int ONLY_ONE_POP = 100001;
    public static final int DOUBLE_POP = 100002;
    public static final int TRIPLE_POP = 100003;
    //作为结果数据正常的标识（是一串乱码）
    public static final String FINISHED_FLAG = "F#I@N%I…S&H";
}
