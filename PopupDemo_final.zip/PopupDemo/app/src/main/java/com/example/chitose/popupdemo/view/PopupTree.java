package com.example.chitose.popupdemo.view;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chitose.popupdemo.R;
import com.example.chitose.popupdemo.adapter.PopAdapter;
import com.example.chitose.popupdemo.entity.PopItem;
import com.example.chitose.popupdemo.helper.PopupHelper;

import java.util.ArrayList;
import java.util.List;

import static com.example.chitose.popupdemo.helper.StaticUtils.*;

/**
 * Created by Chitose on 2018/4/30.
 */

public class PopupTree {

    private Context mContext;
    private List<PopItem> itemList;
    private TextView mSelectTv;
    private int height;

    //popupWindow可以在activity中被调用
    public PopupWindow popupWindow;

    //results[0]~results[2]都是用来存放点击结果，results[3]是作为“结果正常”的标识
    private String[] results = new String[4];

    //初始化两个存放PopItem的List
    final List<PopItem> firstList = new ArrayList<>();
    final List<List<PopItem>> secondList = new ArrayList<>();

    //初始化两个用来改变第二第三列数据的mList
    final List<PopItem> mList = new ArrayList<>();
    final List<PopItem> mList2 = new ArrayList<>();

    //仅一级时的下拉列表菜单栏
    public PopupTree(Context mContext, final List<PopItem> itemList, final TextView mSelectTv, int height) {

        this.mContext = mContext;
        this.itemList = itemList;
        this.mSelectTv = mSelectTv;
        this.height = height;

        //辨别菜单列表的类型是一级，二级还是三级
        switch (PopupHelper.popSort(itemList)) {
            case ONLY_ONE_POP:
                initOnePop();
                break;
            case DOUBLE_POP:
                initDoublePop();
                break;
            case TRIPLE_POP:
                initTriplePop();
                break;
            default:
                Toast.makeText(mContext, "大于三级的列表暂未开发", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    /*一级菜单*/
    private void initOnePop() {

        //Listview与适配器的初始化
        View view = LayoutInflater.from(mContext).inflate(R.layout.popup_one_layout, null);
        ListView mListView = view.findViewById(R.id.pop_listview);
        final PopAdapter mAdapter = new PopAdapter(mContext, itemList);
        mListView.setAdapter(mAdapter);

        //初始化PopupWindow
        popupWindow = new MenuPopup(view, WindowManager.LayoutParams.MATCH_PARENT, height, true, mContext, mSelectTv);

        // 设置ListView点击事件监听
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                // 只有一级的菜单可以直接在这里设置结果放入result[0]中
                results[0] = itemList.get(position).getContent();
                results[3] = FINISHED_FLAG;

                // 选择完后关闭popup窗口
                popupWindow.dismiss();
            }
        });
    }


    /*二级菜单*/
    private void initDoublePop() {

        //初始化两个List
        final List<PopItem> firstList = new ArrayList<>();
        final List<List<PopItem>> secondList = new ArrayList<>();

        //初始化用于控制第二级菜单变化的List
        final List<PopItem> mList = new ArrayList<>();

        //为两个List中的数据初始化
        PopupHelper.popListSort(firstList, secondList, itemList);

        //初始化PopupWindow
        View view = LayoutInflater.from(mContext).inflate(R.layout.popup_double_layout, null);
        ListView firstListView = view.findViewById(R.id.pop_listview_left);
        ListView secondListView = view.findViewById(R.id.pop_listview_right);
        popupWindow = new MenuPopup(view, WindowManager.LayoutParams.MATCH_PARENT, height, true, mContext, mSelectTv);

        //适配器的初始化
        final PopAdapter firstAdapter = new PopAdapter(mContext, firstList);
        firstListView.setAdapter(firstAdapter);
        final PopAdapter secondAdapter = new PopAdapter(mContext, mList);
        secondListView.setAdapter(secondAdapter);

        //初始状态（若第一列第一个元素的二级数据存在，就把第二列显示出来）
        List<PopItem> temp = secondList.get(firstList.get(0).getId());
        if (temp != null) {
            mList.addAll(temp);
        }

        //点击事件
        firstListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //选择了第一列元素相应的数据放到result[0]中
                results[0] = firstList.get(position).getContent();

                //尝试获取当前第一列选项的二级数据
                List<PopItem> list2 = null;
                try {

                    list2 = secondList.get(firstList.get(position).getId());
                } catch (IndexOutOfBoundsException e) {
                    e.printStackTrace();
                }

                //如果没有二级数据，则直接跳转
                if (list2 == null || list2.size() == 0) {
                    results[3] = FINISHED_FLAG;
                    popupWindow.dismiss();
                }
                //如果有则替换并notify
                else {
                    mList.clear();
                    mList.addAll(list2);
                    secondAdapter.notifyDataSetChanged();
                }
            }
        });
        secondListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //没有选择第一列元素就选第二列元素情况下默认第一列选项为第一项
                if (TextUtils.isEmpty(results[0])) {
                    results[0] = firstList.get(0).getContent();
                }

                //选择了第二列元素相应的数据放到result[1]中
                results[1] = mList.get(position).getContent();
                results[3] = FINISHED_FLAG;
                popupWindow.dismiss();
            }
        });
    }

    /*三级菜单*/
    private void initTriplePop() {

        //初始化两个List中的数据
        PopupHelper.popListSort(firstList, secondList, itemList);


        //初始化PopupWindow
        View view = LayoutInflater.from(mContext).inflate(R.layout.popup_triple_layout, null);
        ListView firstListView = view.findViewById(R.id.pop_listview_left);
        ListView secondListView = view.findViewById(R.id.pop_listview_center);
        ListView thirdListView = view.findViewById(R.id.pop_listview_right);
        popupWindow = new MenuPopup(view, WindowManager.LayoutParams.MATCH_PARENT, height, true, mContext, mSelectTv);

        //设置Adapter
        final PopAdapter firstAdapter = new PopAdapter(mContext, firstList);
        firstListView.setAdapter(firstAdapter);
        final PopAdapter secondAdapter = new PopAdapter(mContext, mList);
        secondListView.setAdapter(secondAdapter);
        final PopAdapter thirdAdapter = new PopAdapter(mContext, mList2);
        thirdListView.setAdapter(thirdAdapter);

        //初始化状态（若第二列存在元素就显示→显示后若第三行有也同理显示）
        List<PopItem> temp1 = secondList.get(firstList.get(0).getId());
        if (temp1 != null) {
            mList.addAll(temp1);
            List<PopItem> temp2 = secondList.get(temp1.get(0).getId());
            if (temp2 != null) {
                mList2.addAll(temp2);
            }
        }

        //点击事件
        firstListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //选择了第一列元素相应的数据放到result[0]中
                results[0] = firstList.get(position).getContent();

                //尝试获取当前第一列选项的二级数据
                List<PopItem> list2 = null;
                try {
                    list2 = secondList.get(firstList.get(position).getId());
                } catch (IndexOutOfBoundsException e) {
                    e.printStackTrace();
                }

                //如果没有二级数据，则直接跳转
                if (list2 == null || list2.size() == 0) {
                    results[3] = FINISHED_FLAG;
                    popupWindow.dismiss();
                }
                //如果有则替换并notify
                else {
                    //点击第一项的初始状态
                    mList.clear();
                    mList.addAll(list2);
                    mList2.clear();
                    if (secondList.get(list2.get(0).getId()) != null) {
                        mList2.addAll(secondList.get(list2.get(0).getId()));
                    }
                    secondAdapter.notifyDataSetChanged();
                    thirdAdapter.notifyDataSetChanged();
                }
            }
        });
        secondListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //选择了第二列元素相应的数据放到result[1]中
                results[1] = mList.get(position).getContent();

                //没有选择第一列元素就选第二列元素情况下默认第一列选项为第一项
                if (TextUtils.isEmpty(results[0])) {
                    results[0] = firstList.get(0).getContent();
                }

                //尝试获取当前第二列选项的三级数据
                List<PopItem> list3 = null;
                try {
                    list3 = secondList.get(mList.get(position).getId());
                } catch (IndexOutOfBoundsException e) {
                    e.printStackTrace();
                }

                //如果没有三级数据，则直接跳转
                if (list3 == null || list3.size() == 0) {
                    results[3] = FINISHED_FLAG;
                    popupWindow.dismiss();
                }
                //如果有则替换并notify
                else {
                    mList2.clear();
                    mList2.addAll(list3);
                    thirdAdapter.notifyDataSetChanged();
                }
            }
        });

        thirdListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //没有选择第一列元素就选第三列元素情况下默认第一列选项为第一项
                if (TextUtils.isEmpty(results[0])) {
                    results[0] = firstList.get(0).getContent();
                }

                //没有选择第二列元素就选第三列元素情况下默认第二列选项为第一项
                if (TextUtils.isEmpty(results[1])) {
                    results[1] = mList.get(0).getContent();
                }

                //选择了第三列元素相应的数据放到result[2]中
                results[2] = mList2.get(position).getContent();
                results[3] = FINISHED_FLAG;
                popupWindow.dismiss();
            }
        });
    }

    //用于将结果返回到activity去
    public String[] getResult() {
        return results;
    }

}


