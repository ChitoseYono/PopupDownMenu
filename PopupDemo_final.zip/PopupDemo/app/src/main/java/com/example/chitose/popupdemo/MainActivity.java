package com.example.chitose.popupdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chitose.popupdemo.view.PopupTree;
import com.example.chitose.popupdemo.entity.PopItem;

import java.util.ArrayList;
import java.util.List;

import static com.example.chitose.popupdemo.DataInit.*;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //三个按钮和整体布局
    private TextView tv_demo;
    private TextView tv_demo2;
    private TextView tv_demo3;

    //存放列表数据的List
    private List<PopItem> itemList = new ArrayList<>();
    private List<PopItem> itemList2 = new ArrayList<>();
    private List<PopItem> itemList3 = new ArrayList<>();

    //黑色背景布局
    private View darkView;
    private Animation animIn;
    private Animation animOut;
    private String[] results;
    private PopupTree p1;
    private PopupTree p2;
    private PopupTree p3;

    //优化点击效果用的标记
    boolean popFlag1 = true;
    boolean popFlag2 = true;
    boolean popFlag3 = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initData();
        initView();
    }

    private void initView() {
        //三个按钮的初始化
        tv_demo = findViewById(R.id.tv_demo);
        tv_demo2 = findViewById(R.id.tv_demo2);
        tv_demo3 = findViewById(R.id.tv_demo3);
        tv_demo.setOnClickListener(this);
        tv_demo2.setOnClickListener(this);
        tv_demo3.setOnClickListener(this);

        //黑色背景的初始化
        animIn = AnimationUtils.loadAnimation(this, R.anim.fade_in_anim);
        animOut = AnimationUtils.loadAnimation(this, R.anim.fade_out_anim);
        darkView = findViewById(R.id.main_darkview);
        darkView.startAnimation(animIn);
        darkView.setVisibility(View.GONE);

        //用于给按钮外的布局加点击事件以优化点击效果
        LinearLayout layout = findViewById(R.id.full);
        layout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.tv_demo:

                //避免另外两个pop窗口还存在的情况
                if (p2 != null) {
                    p2.popupWindow.dismiss();
                    popFlag2 = true;
                }
                if (p3 != null) {
                    p3.popupWindow.dismiss();
                    popFlag3 = true;
                }

                //背景颜色变暗
                darkView.startAnimation(animIn);
                darkView.setVisibility(View.VISIBLE);

                //利用popFlag来实现连续点击同一按钮，点了一次再点外面布局的pop窗弹出效果
                if (popFlag1) {
                    tv_demo.setSelected(true);
                    p1 = new PopupTree(this, itemList, tv_demo,375);
                    p1.popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                        @Override
                        public void onDismiss() {

                            //背景颜色变回正常
                            darkView.startAnimation(animOut);
                            darkView.setVisibility(View.GONE);

                            //用getResult来获取数据
                            results = p1.getResult();

                            //处理数据方式要防止取得的数据是不正常的数据
                            if (results[0] != null) {
                                tv_demo.setText(results[0]);
                                Toast.makeText(MainActivity.this, results[0], Toast.LENGTH_SHORT).show();
                            }
                            popFlag1 = !popFlag1;                         //避免点列表项后pop窗口弹出异常
                            tv_demo.setSelected(false);
                        }
                    });
                    popFlag1 = !popFlag1;                                 //实现第二次点击收回的效果
                } else {
                    p1.popupWindow.dismiss();
                    popFlag1 = true;

                    //背景颜色变回正常
                    darkView.startAnimation(animOut);
                    darkView.setVisibility(View.GONE);
                }
                break;

            case R.id.tv_demo2:

                //避免另外两个pop窗口还存在的情况
                if (p1 != null) {
                    p1.popupWindow.dismiss();
                    popFlag1 = true;
                }
                if (p3 != null) {
                    p3.popupWindow.dismiss();
                    popFlag3 = true;
                }

                //背景颜色变暗
                darkView.startAnimation(animIn);
                darkView.setVisibility(View.VISIBLE);

                //利用popFlag来实现连续点击同一按钮，点了一次再点外面布局的pop窗弹出效果
                if (popFlag2) {
                    tv_demo2.setSelected(true);
                    p2 = new PopupTree(this, itemList2, tv_demo2,375);
                    p2.popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                        @Override
                        public void onDismiss() {

                            //背景颜色变回正常
                            darkView.startAnimation(animOut);
                            darkView.setVisibility(View.GONE);

                            //获取数据直接使用getResult方法
                            results = p2.getResult();

                            //处理数据方式要防止取得的数据是不正常的数据
                            if (results[3] != null) {
                                if (results[0] != null) {
                                    if (results[1] != null) {
                                        tv_demo2.setText(results[1]);
                                    } else {
                                        tv_demo2.setText(results[0]);
                                    }
                                    Toast.makeText(MainActivity.this, results[0] + "+" + results[1], Toast.LENGTH_SHORT).show();
                                }
                            }
                            popFlag2 = !popFlag2;                   //避免点列表项后pop窗口弹出异常
                            tv_demo2.setSelected(false);
                        }
                    });
                    popFlag2 = !popFlag2;                           //实现第二次点击收回的效果
                } else {
                    p2.popupWindow.dismiss();
                    popFlag2 = true;

                    //背景颜色变回正常
                    darkView.startAnimation(animOut);
                    darkView.setVisibility(View.GONE);
                }
                break;
            case R.id.tv_demo3:

                //避免另外两个pop窗口还存在的情况
                if (p1 != null) {
                    p1.popupWindow.dismiss();
                    popFlag1 = true;
                }
                if (p2 != null) {
                    p2.popupWindow.dismiss();
                    popFlag2 = true;
                }

                //背景颜色变暗
                darkView.startAnimation(animIn);
                darkView.setVisibility(View.VISIBLE);

                //利用popFlag来实现连续点击同一按钮，点了一次再点外面布局的pop窗弹出效果
                if (popFlag3) {
                    tv_demo3.setSelected(true);
                    p3 = new PopupTree(this, itemList3, tv_demo3,375);
                    p3.popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                        @Override
                        public void onDismiss() {

                            //背景颜色变回正常
                            darkView.startAnimation(animOut);
                            darkView.setVisibility(View.GONE);

                            //获取数据直接使用getResult方法
                            results = p3.getResult();

                            //处理数据方式要防止取得的数据是不正常的数据
                            if (results[3] != null) {
                                if (results[0] != null) {
                                    if (results[1] != null) {
                                        if (results[2] != null) {
                                            tv_demo3.setText(results[2]);
                                        } else {
                                            tv_demo3.setText(results[1]);
                                        }
                                    } else {
                                        tv_demo3.setText(results[0]);
                                    }
                                    Toast.makeText(MainActivity.this, results[0] + "+" + results[1] + "+" + results[2], Toast.LENGTH_SHORT).show();
                                }
                            }
                            popFlag3 = !popFlag3;                   //避免点列表项后pop窗口弹出异常
                            tv_demo3.setSelected(false);
                        }
                    });
                    popFlag3 = !popFlag3;                           //实现第二次点击收回的效果
                } else {
                    p3.popupWindow.dismiss();
                    popFlag3 = true;
                    //背景颜色变回正常
                    darkView.startAnimation(animOut);
                    darkView.setVisibility(View.GONE);
                }
                break;
            case R.id.full:

                //点击按钮以外的布局要把可能有的pop全部清除
                if (p1 != null) {
                    p1.popupWindow.dismiss();
                    popFlag1 = true;
                }
                if (p2 != null) {
                    p2.popupWindow.dismiss();
                    popFlag2 = true;
                }
                if (p3 != null) {
                    p3.popupWindow.dismiss();
                    popFlag3 = true;
                }
        }
    }


    private void initData() {

        //初始化数据
        initFirstData(itemList);
        initSecondData(itemList2);
        initThirdData(itemList3);
    }

}
