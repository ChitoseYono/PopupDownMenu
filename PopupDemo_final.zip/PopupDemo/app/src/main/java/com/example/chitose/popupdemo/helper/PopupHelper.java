package com.example.chitose.popupdemo.helper;

import com.example.chitose.popupdemo.entity.PopItem;

import java.util.ArrayList;
import java.util.List;

import static com.example.chitose.popupdemo.helper.StaticUtils.*;

/**
 * Created by Chitose on 2018/4/30.
 */

public class PopupHelper {

    public static int popSort(List<PopItem> itemList){

        boolean doubleFlag = false;

        for (PopItem item: itemList) {
            //是否只有一级菜单栏
            if(item.getPid()==0){}
            else if(itemList.get(item.getPid()-1).getPid()==0){
                doubleFlag = true;
            }//三级菜单栏
            else{
                return TRIPLE_POP;
            }
        }
        //二级菜单栏
        if(doubleFlag){
            return DOUBLE_POP;
        }
        //一级菜单栏
        else{
            return ONLY_ONE_POP;
        }
    }

    public static void popListSort(List<PopItem> firstList, List<List<PopItem>> secondList, List<PopItem> itemList){

        //secondList.get(0)永远设置为空，方便以后的get可以直接get对应PopItem的id作为索引
        secondList.add(new ArrayList<PopItem>());
        //mList用id来将全部数据的形式存储
        List<List<Integer>> mList = new ArrayList<>();

//        遍历一次itemList，
//        每遍历一个popItem元素，都给mList.add(null)
//        然后分情况
//①Pid为0的元素，不做任何操作
//②Pid不为0的元素，给mList.get(Pid).add(id)
//        这样得到的mList上的第i个元素，
//        如果mList.get(i)!=null,说明他是有子节点的结点
//        若为null则是没有子节点的结点

        for(PopItem item :itemList){
            mList.add(new ArrayList<Integer>());
            if(item.getPid()>0){
                mList.get(item.getPid()-1).add(item.getId());
            }
        }
        for(int i = 0 ; i < mList.size() ; i++){
            List<Integer> list = mList.get(i);
            secondList.add(new ArrayList<PopItem>());
            PopItem item = itemList.get(i);

            if(item.getPid()==0){
                firstList.add(item);
            }
            if(list!=null) {
                for (int j = 0; j < list.size(); j++) {
                    secondList.get(item.getId()).add(itemList.get(list.get(j)-1));
                }
            }
        }

    }


}
